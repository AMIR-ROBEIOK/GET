#Copyright (C) 2023 get

version= "3.0.6"
copyright = " توسط تیم متود درس شده و در سال 2023 منتشر شده \n\n"
Arian = "ArianBOT"

class chup:
	pchap = print(f"Arsein library version {version}\n{copyright}\n☞ library get \n\nدر حال فعال شدن کمی صبور باشید...\n")
	print(" ")
	print(". . . . . . . . . . . ")

