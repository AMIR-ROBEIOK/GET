How to import rubiran's library is as follows:

<< from get import get >>

An example:

from get import get

bot = robiran("Your Auth Account")