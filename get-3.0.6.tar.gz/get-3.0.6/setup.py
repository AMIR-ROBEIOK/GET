import os
import re
from setuptools import setup

_long_description = """

## An example:
``` python
from get import get
key = ""
auth = ""
bot = rubiran(auth,key)

gap = "guids"

bot.sendMessage(gap,"get")
```
### How to install  library

```bash
pip install aiohttp
pip install pycryptodome
pip install pillow
```

### How to import the Rubik's library

``` bash
from get import get
```

### How to install the library

``` bash
pip install get
```

### My ID in Rubika

``` bash
### @GET_ERER
```
## And My ID Channel in Rubika

``` bash
### @get_iran 
```
"""

setup(
    name = "get",
    version = "3.0.6",
    author = "get",
    author_email = "snashna47@gmail.com",
    description = ("Another example of the library making the Rubik's robot"),
    license = "MIT",
    keywords = ["rubika","bot","robot","library","rubikalib","rubikalib.ml","rubikalib.ir","rubika.ir","Rubika","Python","Pyrubika","pyrubika"],
    url = "https://rubika.ir/get_iran",
    packages=['rubiran'],
    long_description=_long_description,
    long_description_content_type = 'text/markdown',
    classifiers=[
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Developers',
    'Topic :: Software Development :: Build Tools',
    'License :: OSI Approved :: MIT License',
    "Programming Language :: Python :: Implementation :: PyPy",
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.4',
    'Programming Language :: Python :: 3.5',
    'Programming Language :: Python :: 3.6',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10'
    ],
)
